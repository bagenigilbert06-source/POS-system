import Link from 'next/link'
import {
  ArrowRight,
  BadgeDollarSign,
  Boxes,
  Building2,
  CircleAlert,
  CreditCard,
  Package,
  PackageOpen,
  ReceiptText,
  ShoppingBag,
  TrendingUp,
  TriangleAlert,
  ShieldCheck,
  UsersRound,
  BarChart3,
} from 'lucide-react'
import { formatCurrency, formatNumber } from '@/lib/utils/format'
import { cn } from '@/lib/utils'
import type { WorkspaceConfig } from '@/lib/types/workspace'
import type { DashboardOverview } from '@/lib/services/dashboard-overview-service'
import { OperatingChart } from './operating-chart'
import { getBusinessExperience } from '@/lib/workspace/business-experience'
import { DashboardInsightCharts } from './dashboard-insight-charts'
import { POSOperationsDashboard } from './pos-operations-dashboard'
import { TimeGreeting } from '../time-greeting'
import { PermissionEnum, RoleEnum } from '@/lib/types/permissions'

interface BusinessOverviewProps {
  organizationName: string
  userName?: string | null
  timeZone: string
  currency: string
  overview: DashboardOverview
  workspaceConfig: WorkspaceConfig
  generatedAt: Date
  role: RoleEnum
  permissions: readonly PermissionEnum[]
}

// Shared visual tokens so every card/panel in this file stays pixel-consistent.
// Every value below already exists elsewhere in this file — nothing new introduced.
const PANEL =
  'rounded-2xl border border-[rgba(255,214,10,0.08)] bg-[rgba(255,255,255,0.03)] shadow-dark-sm backdrop-blur-sm'
const DIVIDER = 'border-[rgba(255,214,10,0.08)]'
const ALERT_ICON = 'border-[rgba(255,105,107,0.24)] bg-[rgba(255,105,107,0.1)] text-[#ff6961]'
const BRAND_ICON = 'border-[rgba(255,214,10,0.16)] bg-[rgba(255,214,10,0.06)] text-[#ffd60a]'

function methodLabel(method: string) {
  return method.replace(/[_-]/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase())
}

export function BusinessOverview({ organizationName, userName, timeZone, currency, overview, workspaceConfig, generatedAt, role, permissions }: BusinessOverviewProps) {
  const experience = getBusinessExperience(workspaceConfig.businessType, workspaceConfig.businessCategory)
  const hasProducts = workspaceConfig.enabledModules.includes('products')
  const hasInventory = workspaceConfig.enabledModules.includes('inventory')
  const hasCustomers = workspaceConfig.enabledModules.includes('customers')
  const saleHref = workspaceConfig.enabledModules.includes('pos') ? '/dashboard/pos' : '/dashboard/sales'
  const isNewWorkspace = overview.recentSales.length === 0
  const availableActions = [
    ...((workspaceConfig.enabledModules.includes('pos') || workspaceConfig.enabledModules.includes('sales')) && permissions.includes(PermissionEnum.POS_VIEW) ? [{ id: 'primary', label: experience.actionLabels.primary, href: saleHref, icon: ShoppingBag, primary: true, description: 'Record a new sale' }] : []),
    ...(hasProducts && permissions.includes(PermissionEnum.PRODUCT_VIEW) ? [{ id: 'products', label: experience.actionLabels.products, href: '/dashboard/products', icon: Package, primary: false, description: 'Manage products' }] : []),
    ...(hasInventory && permissions.includes(PermissionEnum.INVENTORY_VIEW) ? [{ id: 'inventory', label: experience.actionLabels.inventory, href: '/dashboard/inventory', icon: Boxes, primary: false, description: 'Check stock levels' }] : []),
    ...(hasCustomers && permissions.includes(PermissionEnum.CUSTOMER_VIEW) ? [{ id: 'customers', label: 'Customers', href: '/dashboard/customers', icon: UsersRound, primary: false, description: 'Manage customers' }] : []),
    ...(workspaceConfig.enabledModules.includes('reports') && permissions.includes(PermissionEnum.REPORT_VIEW) ? [{ id: 'reports', label: 'Reports', href: '/dashboard/reports', icon: BarChart3, primary: false, description: 'View insights' }] : []),
  ]
  const primaryAction = availableActions.find((action) => action.primary)
  const secondaryActions = availableActions.filter((action) => !action.primary)

  const transactionAverage = overview.today.transactions ? overview.today.revenue / overview.today.transactions : 0
  const commerceMetrics = experience.kind === 'retail' || experience.kind === 'hospitality'
  const metrics = [
    { label: experience.metricLabels[0], value: formatCurrency(overview.today.revenue, currency), detail: `${formatNumber(overview.today.transactions)} completed`, meta: 'Gross sales recorded today', context: 'Today', icon: TrendingUp, href: '/dashboard/sales' },
    commerceMetrics
      ? { label: experience.metricLabels[1], value: formatNumber(overview.today.transactions), detail: experience.kind === 'hospitality' ? 'Completed counter orders' : 'Completed sales', meta: `${formatCurrency(overview.today.revenue, currency)} processed`, context: 'Today', icon: ReceiptText, href: '/dashboard/sales' }
      : { label: experience.metricLabels[1], value: formatCurrency(overview.today.expenses, currency), detail: 'Recorded today', meta: 'Operating costs logged', context: 'Today', icon: CreditCard, href: '/dashboard/expenses' },
    commerceMetrics
      ? { label: experience.metricLabels[2], value: formatCurrency(transactionAverage, currency), detail: experience.kind === 'hospitality' ? 'Per completed order' : 'Per completed sale', meta: `${formatNumber(overview.today.transactions)} transactions`, context: 'Average', icon: BadgeDollarSign, href: '/dashboard/sales' }
      : { label: experience.metricLabels[2], value: formatCurrency(overview.today.operatingPosition, currency), detail: 'Sales less expenses', meta: 'Net operating position', context: 'Today', icon: BadgeDollarSign, href: '/dashboard/reports' },
    ...(hasInventory && commerceMetrics
      ? experience.kind === 'hospitality'
        ? [{ label: experience.metricLabels[3], value: formatNumber(overview.records.products), detail: 'Available menu items', icon: Package, href: '/dashboard/products' }]
        : [{ label: experience.metricLabels[3], value: formatNumber(overview.records.lowStock), detail: `${overview.records.outOfStock} out of stock`, meta: `${formatNumber(overview.records.products)} products tracked`, context: 'Needs attention', icon: TriangleAlert, href: '/dashboard/inventory', alert: true }]
      : hasInventory ? [{ label: 'Stock alerts', value: formatNumber(overview.records.lowStock), detail: `${overview.records.outOfStock} out of stock`, meta: `${formatNumber(overview.records.products)} products tracked`, context: 'Needs attention', icon: TriangleAlert, href: '/dashboard/inventory', alert: true }] : []),
    ...(!hasInventory && hasCustomers ? [{ label: 'Customer records', value: formatNumber(overview.records.customers), detail: 'Available in this workspace', icon: UsersRound }] : []),
    ...(!hasInventory && !hasCustomers ? [{ label: 'Locations', value: formatNumber(overview.records.branches), detail: 'Active business locations', icon: Building2 }] : []),
  ]

  const updatedAt = generatedAt.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit' })

  return (
    <div className="dashboard-overview mx-auto w-full max-w-[1440px] space-y-4 pb-8">

      {/* ---------------------------------------------------------------- */}
      {/* Header                                                           */}
      {/* ---------------------------------------------------------------- */}
      <header className="dashboard-welcome relative overflow-hidden rounded-2xl border border-[#eadfbd] bg-gradient-to-br from-[#fff8df] via-white to-[#f5f7fa] px-5 py-5 shadow-[0_8px_24px_rgb(15_23_42_/_0.04)] sm:px-6 sm:py-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="dashboard-live-status"><i /> Live overview</span>
              <span className="dashboard-updated">Updated {updatedAt}</span>
            </div>
            <p className="mt-3 text-[0.68rem] font-bold uppercase tracking-[0.14em] text-[#9a6700]">
              {role === RoleEnum.MANAGER ? 'Manager · Branch operations' : role === RoleEnum.ADMIN ? 'Admin · Organization overview' : 'Owner · Organization overview'}
            </p>
            <h1 className="mt-1.5 text-[1.7rem] font-bold leading-tight tracking-tight text-[#172033] sm:text-[1.95rem]">
              <TimeGreeting name={userName} timeZone={timeZone} />
            </h1>
            <p className="mt-2 max-w-lg text-sm leading-6 text-[#64748b]">
              {role === RoleEnum.MANAGER ? `Today's performance and attention items for your assigned ${overview.records.branches === 1 ? 'branch' : 'branches'}.` : `Today's organization-wide overview for ${organizationName}.`}
            </p>
          </div>

          {/* Primary action stands alone; everything else lives in one quiet toolbar. */}
          <div className="flex flex-wrap items-center gap-2 lg:shrink-0">
            {primaryAction && (
              <Link
                href={primaryAction.href}
                className="inline-flex h-9 items-center gap-2 rounded-lg bg-[#ffd21f] px-3.5 text-sm font-semibold text-[#172033] shadow-[0_4px_10px_rgb(154_103_0_/_0.12)] outline-none transition-all hover:bg-[#f5c900] hover:shadow-[0_6px_14px_rgb(154_103_0_/_0.18)] focus-visible:ring-2 focus-visible:ring-[#d6a800] focus-visible:ring-offset-2"
              >
                <primaryAction.icon className="h-4 w-4" aria-hidden="true" />
                {primaryAction.label}
              </Link>
            )}

            {secondaryActions.length > 0 && (
              <div className="flex items-center divide-x divide-[#eadfbd] overflow-hidden rounded-lg border border-[#dfe3ea] bg-white">
                {secondaryActions.map((action) => {
                  const Icon = action.icon
                  return (
                    <Link
                      key={action.href}
                      href={action.href}
                      className="inline-flex h-9 items-center gap-2 px-3 text-sm font-medium text-[#334155] outline-none transition-colors hover:bg-[#f8fafc] focus-visible:relative focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#d6a800]"
                    >
                      <Icon className="h-4 w-4" aria-hidden="true" />
                      <span className="hidden xl:inline">{action.label}</span>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* ---------------------------------------------------------------- */}
      {/* Metrics                                                          */}
      {/* ---------------------------------------------------------------- */}
      <section aria-label="Today's operating metrics">
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {metrics.map((metric) => {
            const Icon = metric.icon
            const isAlert = 'alert' in metric && metric.alert
            const metricTone = isAlert ? 'metric-alert' : 'metric-positive'
            const card = (
              <div className={cn('dashboard-metric-card', metricTone, PANEL, 'relative flex h-full flex-col overflow-hidden px-4 py-3.5 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_8px_20px_rgb(15_23_42_/_0.08)]')}>
                {isAlert && <span className="absolute inset-x-0 top-0 h-0.5 bg-[#d95c52]" aria-hidden="true" />}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 flex-wrap items-center gap-2">
                    <p className="truncate text-[0.68rem] font-semibold uppercase tracking-[0.08em] text-[#7d8da6]">{metric.label}</p>
                    {metric.context && (
                      <span className={cn('inline-flex rounded-full px-1.5 py-0.5 text-[0.58rem] font-medium normal-case tracking-normal', isAlert ? 'bg-[rgba(255,105,107,0.1)] text-[#ff6961]' : 'bg-[rgba(255,214,10,0.08)] text-[#8795aa]')}>
                        {metric.context}
                      </span>
                    )}
                  </div>
                  <span className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border', isAlert ? ALERT_ICON : BRAND_ICON)}>
                    <Icon className="h-4 w-4" strokeWidth={1.8} aria-hidden="true" />
                  </span>
                </div>

                <p className={cn('mt-2.5 truncate text-[1.55rem] font-bold leading-none tabular-nums tracking-tight', isAlert ? 'text-[#c9564a]' : 'text-[#172033]')}>{metric.value}</p>
                <p className="mt-1 text-[0.72rem] text-[#8795aa]">{metric.detail}</p>

                {metric.href && (
                  <div className="mt-2.5 flex items-center justify-between gap-3 border-t border-[rgba(255,214,10,0.06)] pt-2.5">
                    <span className="truncate text-[0.66rem] text-[#8795aa]">{metric.meta}</span>
                    <span className="inline-flex shrink-0 items-center gap-1 text-[0.66rem] font-semibold text-[#9a6700]">
                      View details <ArrowRight className="h-3 w-3" />
                    </span>
                  </div>
                )}
              </div>
            )
            return metric.href ? (
              <Link key={metric.label} href={metric.href} className="block h-full rounded-2xl outline-none focus-visible:ring-2 focus-visible:ring-[#ffd60a] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0b0b0d]">
                {card}
              </Link>
            ) : (
              <article key={metric.label} className="h-full">{card}</article>
            )
          })}
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* Insight charts                                                   */}
      {/* ---------------------------------------------------------------- */}
      {!isNewWorkspace && (
        <DashboardInsightCharts
          currency={currency}
          paymentMix={overview.paymentMix}
          topProducts={overview.topProducts}
          stock={{ healthy: overview.records.products - overview.records.lowStock, low: overview.records.lowStock - overview.records.outOfStock, out: overview.records.outOfStock }}
          productLabel={workspaceConfig.businessCategory === 'liquor_shop' ? 'drinks' : 'products'}
        />
      )}

      {/* ---------------------------------------------------------------- */}
      {/* Liquor compliance                                                */}
      {/* ---------------------------------------------------------------- */}
      {workspaceConfig.businessCategory === 'liquor_shop' && (
        <section aria-label="Liquor-store controls">
          <article className={cn(PANEL, 'flex flex-col gap-5 p-5 lg:flex-row lg:items-center')}>
            <div className="flex min-w-0 flex-1 items-center gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[rgba(255,214,10,0.2)] bg-[rgba(255,214,10,0.08)] text-[#ffd60a]">
                <ShieldCheck className="h-5 w-5" />
              </span>
              <div className="min-w-0">
                <h2 className="text-sm font-semibold text-[#f5f5f7]">Liquor sales controls</h2>
                <p className="mt-0.5 max-w-xl text-xs leading-5 text-[#a1a1a6]">Age verification is required at checkout and recorded with each new liquor sale.</p>
              </div>
            </div>

            <div className="flex shrink-0 gap-2">
              <div className="min-w-[96px] rounded-xl border border-[rgba(22,163,106,0.22)] bg-[rgba(22,163,106,0.08)] px-4 py-2.5">
                <p className="text-lg font-semibold tabular-nums text-[#f5f5f7]">{formatNumber(overview.liquorCompliance.verifiedToday)}</p>
                <p className="mt-0.5 text-[10px] font-medium uppercase tracking-[0.08em] text-[#a1a1a6]">Verified today</p>
              </div>
              <div className={cn('min-w-[96px] rounded-xl border px-4 py-2.5', overview.liquorCompliance.unverifiedToday ? 'border-[rgba(255,105,107,0.24)] bg-[rgba(255,105,107,0.1)]' : 'border-[rgba(255,214,10,0.18)] bg-[rgba(255,214,10,0.06)]')}>
                <p className={cn('text-lg font-semibold tabular-nums', overview.liquorCompliance.unverifiedToday ? 'text-[#ff6961]' : 'text-[#f5f5f7]')}>{formatNumber(overview.liquorCompliance.unverifiedToday)}</p>
                <p className="mt-0.5 text-[10px] font-medium uppercase tracking-[0.08em] text-[#a1a1a6]">Needs review</p>
              </div>
            </div>

            <Link href="/dashboard/operations" className="inline-flex h-10 shrink-0 items-center justify-center gap-2 rounded-xl border border-[rgba(255,214,10,0.2)] bg-[rgba(255,255,255,0.05)] px-4 text-sm font-medium text-[#f5f5f7] transition-all hover:border-[rgba(255,214,10,0.3)] hover:bg-[rgba(255,255,255,0.08)]">
              <CircleAlert className="h-4 w-4" />
              Register controls
            </Link>
          </article>
        </section>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* Operating performance + month to date                           */}
      {/* ---------------------------------------------------------------- */}
      <section className="grid items-start gap-4 xl:grid-cols-[minmax(0,1.8fr)_minmax(300px,.72fr)]">
        <article className={cn(PANEL, 'overflow-hidden')}>
          <div className={cn('flex flex-col gap-2.5 border-b px-5 py-3 sm:flex-row sm:items-center sm:justify-between', DIVIDER)}>
            <div>
              <h2 className="text-[0.95rem] font-bold text-[#f5f5f7]">Operating performance</h2>
              <p className="mt-0.5 text-xs text-[#a1a1a6]">Sales and recorded expenses · Live 30-day history</p>
            </div>
            <div className="flex items-center gap-4 text-xs font-medium text-[#a1a1a6]">
              <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-sm bg-[var(--dashboard-chart-revenue)]" />Sales</span>
              <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-sm bg-[var(--dashboard-chart-secondary)]" />Expenses</span>
              <Link href="/dashboard/reports" className="font-semibold text-[#ffd60a] hover:text-[#ffdf3a]">Reports</Link>
            </div>
          </div>
          <div className="px-4 pb-3 pt-4 sm:px-5">
            <OperatingChart data={overview.revenueSeries} currency={currency} />
          </div>
        </article>

        <aside className={cn(PANEL, 'flex h-full min-h-[270px] flex-col overflow-hidden')}>
          <div className={cn('border-b px-5 py-3', DIVIDER)}>
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-[0.95rem] font-semibold text-[#f5f5f7]">Month to date</h2>
                <p className="mt-0.5 text-xs text-[#a1a1a6]">Current operating position</p>
              </div>
              <span className="inline-flex items-center gap-1.5 text-[0.7rem] font-medium text-[#a1a1a6]">
                <i className="dashboard-live-dot h-2 w-2 rounded-full bg-[#ff6961]" />Live
              </span>
            </div>
          </div>

          <dl className={cn('flex flex-1 flex-col justify-center divide-y px-6', DIVIDER)}>
            <SummaryRow label="Sales" value={formatCurrency(overview.month.revenue, currency)} />
            <SummaryRow label="Expenses" value={formatCurrency(overview.month.expenses, currency)} />
            <SummaryRow label="Sales less expenses" value={formatCurrency(overview.month.operatingPosition, currency)} emphasis />
          </dl>

          <div className={cn('grid border-t bg-[rgba(255,214,10,0.04)]', DIVIDER, hasProducts && hasCustomers ? 'grid-cols-3' : hasProducts || hasCustomers ? 'grid-cols-2' : 'grid-cols-1')}>
            {hasProducts && <MiniRecord label="Products" value={formatNumber(overview.records.products)} href="/dashboard/products" />}
            {hasCustomers && <MiniRecord label="Customers" value={formatNumber(overview.records.customers)} href="/dashboard/customers" />}
            <MiniRecord label="Locations" value={formatNumber(overview.records.branches)} href={permissions.includes(PermissionEnum.SETTINGS_VIEW) ? '/dashboard/settings' : '/dashboard/operations'} />
          </div>
        </aside>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* Recent activity + stock                                         */}
      {/* ---------------------------------------------------------------- */}
      <section className={cn('grid items-start gap-4', hasInventory && 'xl:grid-cols-[minmax(0,1.45fr)_minmax(330px,.75fr)]')}>
        <article className={cn(PANEL, 'overflow-hidden')}>
          <SectionHeader title={experience.activityTitle} description={experience.activityDescription} href="/dashboard/sales" />
          {overview.recentSales.length ? (
            <>
              <div className={cn('divide-y sm:hidden', DIVIDER)}>
                {overview.recentSales.map((record) => (
                  <div key={record.id} className="flex items-center justify-between gap-4 px-6 py-3.5">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-[#f5f5f7]">{record.receiptNo}</p>
                      <p className="mt-0.5 text-xs text-[#a1a1a6]">{methodLabel(record.paymentMethod)} · {record.createdAt.toLocaleDateString('en-KE', { day: 'numeric', month: 'short' })}</p>
                    </div>
                    <p className="text-sm font-semibold tabular-nums text-[#f5f5f7]">{formatCurrency(record.total, currency)}</p>
                  </div>
                ))}
              </div>

              <div className="hidden overflow-x-auto sm:block">
                <table className="w-full min-w-[620px] text-left text-sm">
                  <thead className={cn('border-b bg-[rgba(255,214,10,0.04)] text-[0.66rem] uppercase tracking-[0.1em] text-[#a1a1a6]', DIVIDER)}>
                    <tr>
                      <th className="px-6 py-3.5 font-semibold">Receipt</th>
                      <th className="px-4 py-3.5 font-semibold">Date</th>
                      <th className="px-4 py-3.5 font-semibold">Payment</th>
                      <th className="px-6 py-3.5 text-right font-semibold">Total</th>
                    </tr>
                  </thead>
                  <tbody className={cn('divide-y', DIVIDER)}>
                    {overview.recentSales.map((record) => (
                      <tr key={record.id} className="transition-colors hover:bg-[rgba(255,214,10,0.04)]">
                        <td className="px-6 py-3.5 font-semibold text-[#f5f5f7]">{record.receiptNo}</td>
                        <td className="px-4 py-3.5 text-[#a1a1a6]">{record.createdAt.toLocaleString('en-KE', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
                        <td className="px-4 py-3.5 text-[#a1a1a6]">{methodLabel(record.paymentMethod)}</td>
                        <td className="px-6 py-3.5 text-right font-semibold tabular-nums text-[#f5f5f7]">{formatCurrency(record.total, currency)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          ) : (
            <EmptyState message="No transactions yet" detail="Completed sales will appear here automatically." href={saleHref} action="Record the first sale" />
          )}
        </article>

        {hasInventory && (
          <aside className="space-y-5">
            <article className={cn(PANEL, 'overflow-hidden')}>
              <SectionHeader title={experience.stockTitle} description={experience.stockDescription} href="/dashboard/inventory" />
              {overview.lowStockProducts.length ? (
                <div className={cn('divide-y px-6', DIVIDER)}>
                  {overview.lowStockProducts.map((item) => (
                    <div key={item.id} className="flex items-center gap-3 py-3.5">
                      <span className={item.stock <= 0 ? 'h-2 w-2 shrink-0 rounded-full bg-[#ff6961]' : 'h-2 w-2 shrink-0 rounded-full bg-[#ffd60a]'} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-[#f5f5f7]">{item.name}</p>
                        <p className="mt-0.5 truncate text-xs text-[#a1a1a6]">{item.sku || 'No SKU'} · reorder at {item.minStock}</p>
                      </div>
                      <span className={item.stock <= 0 ? 'shrink-0 rounded-lg bg-[rgba(255,105,107,0.15)] px-2.5 py-1 text-xs font-semibold text-[#ff6961]' : 'shrink-0 rounded-lg bg-[rgba(255,214,10,0.15)] px-2.5 py-1 text-xs font-semibold text-[#ffd60a]'}>
                        {item.stock} left
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState message="Stock levels look healthy" detail="No active products currently need attention." href="/dashboard/inventory" action="Review inventory" icon="stock" />
              )}
            </article>

            <TodayRegisterCard currency={currency} revenue={overview.today.revenue} transactions={overview.today.transactions} expenses={overview.today.expenses} saleHref={saleHref} />
          </aside>
        )}
      </section>
    </div>
  )
}

function TodayRegisterCard({ currency, revenue, transactions, expenses, saleHref }: { currency: string; revenue: number; transactions: number; expenses: number; saleHref: string }) {
  const averageSale = transactions ? revenue / transactions : 0
  return (
    <article className={cn(PANEL, 'overflow-hidden')}>
      <div className={cn('flex items-start justify-between gap-3 border-b px-5 py-4', DIVIDER)}>
        <div>
          <h2 className="text-[0.95rem] font-bold text-[#f5f5f7]">Today&apos;s register</h2>
          <p className="mt-0.5 text-xs text-[#a1a1a6]">A quick view of counter activity.</p>
        </div>
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[rgba(255,214,10,0.08)] text-[#ffd60a]">
          <ReceiptText className="h-4 w-4" />
        </span>
      </div>

      <dl className={cn('grid grid-cols-2 divide-x border-b', DIVIDER)}>
        <div className="px-5 py-3.5">
          <dt className="text-[0.66rem] font-medium uppercase tracking-[0.08em] text-[#a1a1a6]">Sales</dt>
          <dd className="mt-1 text-lg font-bold tabular-nums text-[#f5f5f7]">{formatCurrency(revenue, currency)}</dd>
        </div>
        <div className="px-5 py-3.5">
          <dt className="text-[0.66rem] font-medium uppercase tracking-[0.08em] text-[#a1a1a6]">Receipts</dt>
          <dd className="mt-1 text-lg font-bold tabular-nums text-[#f5f5f7]">{formatNumber(transactions)}</dd>
        </div>
      </dl>

      <div className="space-y-2 px-5 py-4 text-sm">
        <div className="flex items-center justify-between gap-3">
          <span className="text-[#a1a1a6]">Average sale</span>
          <strong className="tabular-nums text-[#f5f5f7]">{formatCurrency(averageSale, currency)}</strong>
        </div>
        <div className="flex items-center justify-between gap-3">
          <span className="text-[#a1a1a6]">Recorded expenses</span>
          <strong className="tabular-nums text-[#f5f5f7]">{formatCurrency(expenses, currency)}</strong>
        </div>
      </div>

      <div className={cn('grid grid-cols-2 gap-2 border-t bg-[rgba(255,214,10,0.04)] p-3', DIVIDER)}>
        <Link href={saleHref} className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-[#ffd60a] px-3 text-xs font-bold text-[#0b0b0d] transition-colors hover:bg-[#ffdf3a]">
          <ShoppingBag className="h-3.5 w-3.5" />Start sale
        </Link>
        <Link href="/dashboard/sales" className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-[rgba(255,214,10,0.16)] bg-[rgba(255,255,255,0.04)] px-3 text-xs font-semibold text-[#f5f5f7] transition-colors hover:bg-[rgba(255,255,255,0.08)]">
          View receipts <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </article>
  )
}

function SummaryRow({ label, value, emphasis = false }: { label: string; value: string; emphasis?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3.5">
      <dt className="text-sm text-[#a1a1a6]">{label}</dt>
      <dd className={emphasis ? 'text-base font-bold tabular-nums text-[#f5f5f7]' : 'text-sm font-semibold tabular-nums text-[#f5f5f7]'}>{value}</dd>
    </div>
  )
}

function MiniRecord({ label, value, href }: { label: string; value: string; href: string }) {
  return (
    <Link href={href} className={cn('border-r px-3 py-3.5 text-center transition-colors last:border-r-0 hover:bg-[rgba(255,214,10,0.08)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#ffd60a]', DIVIDER)}>
      <span className="block text-sm font-bold tabular-nums text-[#f5f5f7]">{value}</span>
      <span className="mt-0.5 block text-[0.7rem] text-[#a1a1a6]">{label}</span>
    </Link>
  )
}

function SectionHeader({ title, description, href }: { title: string; description: string; href?: string }) {
  return (
    <div className={cn('flex items-center justify-between gap-4 border-b px-6 py-4', DIVIDER)}>
      <div>
        <h2 className="text-[0.95rem] font-bold text-[#f5f5f7]">{title}</h2>
        <p className="mt-0.5 text-xs text-[#a1a1a6]">{description}</p>
      </div>
      {href && (
        <Link href={href} className="inline-flex shrink-0 items-center gap-1.5 text-xs font-semibold text-[#ffd60a] transition-colors hover:text-[#ffdf3a]">
          View all <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      )}
    </div>
  )
}

function EmptyState({ message, detail, href, action, icon = 'receipt' }: { message: string; detail: string; href: string; action: string; icon?: 'receipt' | 'stock' }) {
  const Icon = icon === 'stock' ? PackageOpen : ReceiptText
  return (
    <div className="flex min-h-44 flex-col items-center justify-center px-6 py-8 text-center">
      <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-[rgba(255,214,10,0.08)] text-[#a1a1a6]">
        <Icon className="h-5 w-5" />
      </span>
      <p className="mt-3 text-sm font-semibold text-[#f5f5f7]">{message}</p>
      <p className="mt-1 max-w-xs text-xs leading-5 text-[#a1a1a6]">{detail}</p>
      <Link href={href} className="mt-4 text-xs font-semibold text-[#ffd60a] hover:text-[#ffdf3a]">{action}</Link>
    </div>
  )
}
