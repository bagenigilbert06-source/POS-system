'use client'

import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

interface OperatingChartProps {
  data: Array<{ date: string; revenue: number; expenses: number }>
  currency: string
}

const RANGES = [
  { value: 1, label: 'Today' },
  { value: 7, label: '7 days' },
  { value: 30, label: '30 days' },
] as const

function compact(value: number, currency: string) {
  const symbols: Record<string, string> = {
    KES: 'Ksh',
    USD: '$',
    EUR: '€',
    GBP: '£',
    UGX: 'USh',
    TZS: 'TSh',
    RWF: 'RF',
  }
  const absolute = Math.abs(value)
  const scale =
    absolute >= 1_000_000_000
      ? { divisor: 1_000_000_000, suffix: 'B' }
      : absolute >= 1_000_000
        ? { divisor: 1_000_000, suffix: 'M' }
        : absolute >= 1_000
          ? { divisor: 1_000, suffix: 'K' }
          : { divisor: 1, suffix: '' }
  const scaled = value / scale.divisor
  const amount = Number.isInteger(scaled) ? String(scaled) : scaled.toFixed(1).replace(/\.0$/, '')

  // Avoid Intl compact-currency formatting here. Its output differs between
  // Node's and browsers' ICU data, which makes the server HTML impossible to
  // hydrate reliably.
  return `${symbols[currency] ?? currency} ${amount}${scale.suffix}`
}

/** Small dot + label used for the Sales / Expenses key above the chart. */
function LegendKey({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--dashboard-muted)]">
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
    </span>
  )
}

export function OperatingChart({ data, currency }: OperatingChartProps) {
  const [range, setRange] = useState<1 | 7 | 30>(30)

  const chartData = useMemo(
    () =>
      data.slice(-range).map((point) => ({
        ...point,
        label: new Date(`${point.date}T12:00:00`).toLocaleDateString(
          'en-KE',
          range === 7 ? { weekday: 'short' } : { day: 'numeric', month: 'short' },
        ),
      })),
    [data, range],
  )

  const hasData = chartData.some((point) => point.revenue > 0 || point.expenses > 0)
  const periodLabel = range === 1 ? 'today' : `the last ${range} days`

  return (
    <div className="rounded-2xl border border-[var(--dashboard-border)] bg-[var(--dashboard-surface)] p-5">
      {/* Header: legend on the left, range switcher on the right */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-4">
          <LegendKey color="var(--dashboard-chart-revenue)" label="Sales" />
          <LegendKey color="var(--dashboard-chart-secondary)" label="Expenses" />
        </div>
        <div
          role="tablist"
          aria-label="Chart period"
          className="flex rounded-lg border border-[var(--dashboard-border)] bg-[var(--dashboard-surface-subtle)] p-1"
        >
          {RANGES.map(({ value, label: rangeLabel }) => (
            <button
              key={value}
              type="button"
              role="tab"
              aria-selected={range === value}
              onClick={() => setRange(value)}
              className={
                range === value
                  ? 'rounded-md bg-[var(--dashboard-surface)] px-3 py-1.5 text-xs font-bold text-[var(--dashboard-text)] shadow-sm'
                  : 'rounded-md px-3 py-1.5 text-xs font-semibold text-[var(--dashboard-muted)] transition-colors hover:text-[var(--dashboard-text)]'
              }
            >
              {rangeLabel}
            </button>
          ))}
        </div>
      </div>

      <div
        className="relative mt-4 h-[220px] w-full sm:h-[240px]"
        role="img"
        aria-label={`Sales and expenses over ${periodLabel}`}
      >
        {!hasData && (
          <div className="flex h-full items-center justify-center">
            <div className="max-w-sm rounded-lg border border-dashed border-[var(--dashboard-border)] px-5 py-4 text-center">
              <p className="text-sm font-semibold text-[var(--dashboard-text)]">No activity for {periodLabel}</p>
              <p className="mt-1 text-xs leading-5 text-[var(--dashboard-muted)]">
                Sales and expenses will appear here after they are recorded.
              </p>
            </div>
          </div>
        )}

        {hasData && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 8, right: 8, left: -8, bottom: 0 }} barCategoryGap={range === 30 ? '48%' : '36%'}>
              <CartesianGrid vertical={false} stroke="var(--dashboard-chart-grid)" strokeDasharray="3 5" />
              <XAxis
                dataKey="label"
                axisLine={false}
                tickLine={false}
                interval={range === 30 ? 4 : 0}
                tick={{ fill: 'var(--dashboard-chart-tick)', fontSize: 11 }}
                dy={10}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                width={56}
                tickCount={4}
                tick={{ fill: 'var(--dashboard-chart-tick)', fontSize: 10 }}
                tickFormatter={(value) => compact(value, currency)}
              />
              <Tooltip
                cursor={{ fill: 'var(--dashboard-surface-subtle)' }}
                contentStyle={{
                  background: 'var(--dashboard-chart-tooltip)',
                  color: 'var(--dashboard-text)',
                  border: '1px solid var(--dashboard-border)',
                  borderRadius: 10,
                  boxShadow: '0 10px 24px rgba(16,24,40,.12)',
                  fontSize: 12,
                  padding: '8px 12px',
                }}
                itemStyle={{ color: 'var(--dashboard-text)' }}
                labelStyle={{ color: 'var(--dashboard-muted)', marginBottom: 4, fontWeight: 600 }}
                formatter={(value, name) => [compact(Number(value), currency), name === 'Sales' ? 'Sales' : 'Expenses']}
                labelFormatter={(_, payload) => payload?.[0]?.payload?.date ?? ''}
              />
              <Bar dataKey="revenue" name="Sales" fill="var(--dashboard-chart-revenue)" radius={[4, 4, 0, 0]} maxBarSize={26} isAnimationActive={false} />
              <Bar dataKey="expenses" name="Expenses" fill="var(--dashboard-chart-secondary)" radius={[4, 4, 0, 0]} maxBarSize={26} isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  )
}